from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_health():
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_research_validation():
    response = client.post("/api/research", json={"question": "Hi", "context": []})
    assert response.status_code == 422
