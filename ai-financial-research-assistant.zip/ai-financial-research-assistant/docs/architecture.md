# Architecture Notes

## Request flow

1. The browser sends a validated research request to FastAPI.
2. The RAG service cleans the provided context and delegates generation to the LLM service.
3. The LLM service uses an OpenAI-compatible client when an API key is configured.
4. The API returns a structured response with an answer and source labels.
5. PostgreSQL is available for persistent document metadata and can be extended to store chunks, embeddings, sessions, and audit information.

## Extension points

- Replace explicit context input with PDF/document ingestion.
- Add an embedding service and vector database.
- Add source-level citations and chunk metadata.
- Add authentication and request logging.
- Add CI checks for tests, formatting, and security scanning.
