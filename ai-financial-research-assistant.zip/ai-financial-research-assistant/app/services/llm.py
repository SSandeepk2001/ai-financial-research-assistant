from openai import OpenAI

from ..config import settings


def generate_answer(question: str, context: list[str]) -> str:
    if not settings.openai_api_key:
        if context:
            return (
                "LLM provider is not configured. Based on the supplied context: "
                + " ".join(context)
            )
        return "LLM provider is not configured. Add OPENAI_API_KEY to enable generated research answers."

    client = OpenAI(api_key=settings.openai_api_key)
    prompt = (
        "You are a financial research assistant. Answer using only the provided context. "
        "State uncertainty when the context does not support a conclusion.\n\n"
        f"Question: {question}\n\nContext:\n" + "\n".join(f"- {item}" for item in context)
    )
    response = client.chat.completions.create(
        model=settings.openai_model,
        temperature=0.2,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.choices[0].message.content or "No answer generated."
