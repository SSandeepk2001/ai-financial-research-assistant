from .llm import generate_answer


def research(question: str, context: list[str]) -> tuple[str, list[str]]:
    # Retrieval can be replaced by embeddings/vector search later.
    cleaned_context = [item.strip() for item in context if item and item.strip()]
    answer = generate_answer(question, cleaned_context)
    sources = [f"Context {index + 1}" for index in range(len(cleaned_context))]
    return answer, sources
