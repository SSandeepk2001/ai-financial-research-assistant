from pydantic import BaseModel, Field


class ResearchRequest(BaseModel):
    question: str = Field(min_length=5, max_length=2000)
    context: list[str] = Field(default_factory=list, max_length=20)


class ResearchResponse(BaseModel):
    answer: str
    sources: list[str]


class DocumentResponse(BaseModel):
    id: int
    title: str
    created_at: str
