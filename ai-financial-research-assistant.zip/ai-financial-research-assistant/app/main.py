from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy import select

from .config import settings
from .db import Base, SessionLocal, engine
from .models import ResearchDocument
from .schemas import DocumentResponse, ResearchRequest, ResearchResponse
from .services.rag import research

Base.metadata.create_all(bind=engine)

app = FastAPI(title=settings.app_name, version="1.0.0")
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")


@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request, "app_name": settings.app_name})


@app.get("/api/health")
def health():
    return {"status": "ok", "service": settings.app_name}


@app.post("/api/research", response_model=ResearchResponse)
def create_research(payload: ResearchRequest):
    answer, sources = research(payload.question, payload.context)
    return ResearchResponse(answer=answer, sources=sources)


@app.get("/api/documents", response_model=list[DocumentResponse])
def list_documents():
    with SessionLocal() as session:
        rows = session.scalars(select(ResearchDocument).order_by(ResearchDocument.created_at.desc())).all()
        return [
            DocumentResponse(id=row.id, title=row.title, created_at=row.created_at.isoformat())
            for row in rows
        ]
