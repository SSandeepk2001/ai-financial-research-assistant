const askButton = document.getElementById("ask");
const result = document.getElementById("result");

if (askButton) {
  askButton.addEventListener("click", async () => {
    result.textContent = "Generating...";
    const question = document.getElementById("question").value;
    const context = document.getElementById("context").value
      .split("\n")
      .map((item) => item.trim())
      .filter(Boolean);

    try {
      const response = await fetch("/api/research", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question, context }),
      });

      const payload = await response.json();
      if (!response.ok) throw new Error(payload.detail || "Request failed");

      result.textContent = `${payload.answer}\n\nSources: ${payload.sources.join(", ") || "None"}`;
    } catch (error) {
      result.textContent = `Error: ${error.message}`;
    }
  });
}
